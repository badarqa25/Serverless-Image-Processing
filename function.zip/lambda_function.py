import boto3
from PIL import Image, ImageDraw, ImageFont
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    download_path = f"/tmp/{os.path.basename(key)}"
    upload_path = f"/tmp/processed-{os.path.basename(key)}"
    output_bucket = "processed-bucket-by-badarqa"

    s3.download_file(bucket, key, download_path)

    with Image.open(download_path) as img:
        img = img.resize((800, 800))
        draw = ImageDraw.Draw(img)
        font = ImageFont.load_default()
        draw.text((10, 10), "© BadarQA", font=font, fill=(255, 255, 255))
        img.convert("RGB").save(upload_path, "JPEG")

    s3.upload_file(upload_path, output_bucket, f"processed-{os.path.basename(key)}")
